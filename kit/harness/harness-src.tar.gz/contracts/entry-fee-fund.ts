// The entry fee's shares (contracts/competition.ts EntryFee): how a fee splits between the bounty's pot, the make.fun
// fund (fund_percent: a house bounty's fund share, or a user's bounty's house share) and the bounty's creator
// (creator, a user's or agent's bounty, less make.fun's cut of that share, which goes to the fund too), and the
// sentences every surface (server, cli, web) uses to tell people and agents about it, with the words for winnings
// still pending, which never pay a fee. The wording is tuned here alone.
//
// Split: house = floor(fee_cents * fund_percent / 100); with a creator share gross = floor(fee_cents * percent / 100)
// and cut = floor(gross * cut_percent / 100) (both 0 without one); the fund's account gets house + cut, the creator's
// gross - cut, the pot the rest (fee - house - gross). fund_percent + percent is at most 100, and a bundle with no
// fund_percent splits as it always did. A fee is whole cents; in base units
// a cent is 10^(decimals - 2) (USDC: 6 decimals, 10_000 base units a cent). Where the creator's net share goes is the
// creator block's `to`: 'balance', credited to the creator's make.fun balance; absent, paid on chain to its wallet.
//
// Floor: every bounty composed from now on keeps at least FUND_FLOOR_PERCENT of each fee for the fund, as its
// fund_percent: on a user's bounty that is its house share, with or without a creator share (fundShareBpsOf counts
// make.fun's cut of a creator's share too; fundFloorIssue says when a fee falls short). The splits above follow a
// bundle's frozen terms, so a bundle sealed before the floor splits as it always did.
//
// A leaf: no imports at all, so the server, the cli and the web app all read it.

/** The fund's name as every sentence says it. */
export const FUND_NAME = 'the make.fun fund';

/** What the fund pays for, as every sentence says it (the user's words: more bounties, more content, expansion). */
export const FUND_PURPOSE = "which pays for more bounties, more content and make.fun's expansion";

/**
 * What winnings not cleared to pay yet are (server/entry-fees/eligible.ts EligibleWinnings.pendingCents), as every
 * surface says them: they never pay an entry fee until they are cleared. The insufficient_winnings refusal carries
 * their amount typed (EntryFeeProblem.winnings_pending_usd); these words only say what that amount is.
 */
export const PENDING_WINNINGS_WORDS = 'still pending (under review, held, or awaiting approval)';

/** How every sentence names the person or agent who created a bounty (EntryFee.creator). */
export const CREATOR_NAME = "the bounty's creator";

/**
 * The most of each entry fee a bounty's creator may keep, in percent: the default of server/config.ts
 * sponsorCreatorMaxPercent (MAKEFUN_SPONSOR_CREATOR_MAX_PERCENT).
 */
export const CREATOR_SHARE_MAX_PERCENT = 50;

/**
 * make.fun's cut of a creator's share, in percent of that share, paid to the fund: the default of server/config.ts
 * sponsorCreatorCutPercent (MAKEFUN_SPONSOR_CREATOR_CUT_PERCENT), frozen into each bundle at compose
 * (EntryFee.creator.cut_percent).
 */
export const CREATOR_SHARE_CUT_PERCENT = 50;

/**
 * make.fun's house share of every entry fee on a user's or agent's bounty, in percent of the whole fee, paid to the
 * fund: the default of server/config.ts sponsorFeeHousePercent (MAKEFUN_SPONSOR_FEE_HOUSE_PERCENT), frozen into each
 * bundle at compose (EntryFee.fund_percent), beside the creator's share and make.fun's cut of it.
 */
export const FEE_HOUSE_PERCENT = 15;

/**
 * The least percent of each entry fee make.fun keeps (to FUND_NAME) on every bounty composed from now on: the
 * owner's words, 2026-11-20, "we keep 15% of all entry fees as a floor going forward". A house bounty keeps it as its
 * fund_percent; a user's or agent's bounty as its house share (fund_percent, never under it: FEE_HOUSE_PERCENT is the
 * default, this the least), beside any creator share and make.fun's cut of it; fundFloorIssue says when a fee falls
 * short. Bundles composed before keep the terms they were sealed with.
 */
export const FUND_FLOOR_PERCENT = 15;

/**
 * Where a creator's net share goes (EntryFee.creator.to; GET /api/sponsor/terms limits.creator_payout): 'balance', credited
 * to the creator's make.fun balance and claimed like other rewards; 'wallet', paid on chain to the creator's wallet.
 */
export const CREATOR_PAYOUTS = ['balance', 'wallet'] as const;
export type CreatorPayout = (typeof CREATOR_PAYOUTS)[number];

/** Where a creator's net share of a bounty composed now goes unless the server says otherwise (MAKEFUN_SPONSOR_CREATOR_PAYOUT). */
export const CREATOR_PAYOUT_DEFAULT: CreatorPayout = 'balance';

/**
 * A creator share's terms (EntryFee.creator without its wallet): its percent of each fee, make.fun's cut of that share,
 * and `to` 'balance' when the creator's net share is credited to their make.fun balance (absent: paid to their wallet).
 */
export interface CreatorShareTerms {
  percent: number;
  cut_percent: number;
  to?: 'balance';
}

/** Where a creator share's net share goes: 'balance' for `to` 'balance', else 'wallet'. */
export function creatorPayoutOf(c: { to?: string }): CreatorPayout {
  return c.to === 'balance' ? 'balance' : 'wallet';
}

/** The terms' `to` key for a payout: `{ to: 'balance' }` in balance mode, else none, so a wallet-mode block keeps its bytes. */
export function creatorToOf(payout: CreatorPayout): Pick<CreatorShareTerms, 'to'> {
  return payout === 'balance' ? { to: 'balance' } : {};
}

/** Throws unless `p` is an integer 0..100 (`name`: EntryFee.fund_percent unless named). */
function assertPercent(p: number, name = 'fund_percent'): void {
  if (!Number.isInteger(p) || p < 0 || p > 100) throw new RangeError(`${name} ${p} is not an integer 0..100`);
}

/**
 * Throws unless `c` holds a creator share beside a fund share of `fundPercent`: percent an integer 1..100, cut_percent
 * an integer 0..100, and fundPercent + percent at most 100 (both are percents of the whole fee).
 */
function assertCreator(c: CreatorShareTerms, fundPercent = 0): void {
  if (!Number.isInteger(c.percent) || c.percent < 1 || c.percent > 100) throw new RangeError(`creator percent ${c.percent} is not an integer 1..100`);
  assertPercent(c.cut_percent, 'creator cut_percent');
  if (fundPercent + c.percent > 100) throw new RangeError(`fund_percent ${fundPercent} and creator percent ${c.percent} are more than 100: both are percents of the whole fee`);
}

/** The fee's fund percent: its fund_percent, 0 when absent (or no fee at all). */
export function fundPercentOf(entryFee: { fund_percent?: number } | null | undefined): number {
  return entryFee?.fund_percent ?? 0;
}

/** The fee's creator share terms (its creator, the wallet dropped, `to` kept in balance mode), null when it has none (or no fee at all). */
export function creatorTermsOf(entryFee: { creator?: CreatorShareTerms } | null | undefined): CreatorShareTerms | null {
  const c = entryFee?.creator;
  return c === undefined ? null : { percent: c.percent, cut_percent: c.cut_percent, ...creatorToOf(creatorPayoutOf(c)) };
}

/** The split in whole cents (the one place it is computed): the fund's share, the creator's gross share and make.fun's cut of it. */
function splitOfCents(cents: bigint, fundPercent: number, creator: CreatorShareTerms | null): { house: bigint; gross: bigint; cut: bigint } {
  assertPercent(fundPercent);
  if (creator !== null) assertCreator(creator, fundPercent);
  const house = (cents * BigInt(fundPercent)) / 100n;
  const gross = creator === null ? 0n : (cents * BigInt(creator.percent)) / 100n;
  const cut = creator === null ? 0n : (gross * BigInt(creator.cut_percent)) / 100n;
  return { house, gross, cut };
}

/** An entry fee as the floor reads it (contracts/competition.ts EntryFee, the fields it needs). */
type FloorEntryFee = { amount_usd?: number; fund_percent?: number; creator?: CreatorShareTerms } | null | undefined;

/**
 * make.fun's share of each fee in basis points, on the fee's exact terms (no cent rounding): fund_percent * 100 plus,
 * with a creator share, creator.percent * creator.cut_percent (make.fun's cut of the creator's share), since a fee
 * feeds the fund and the creator both; 0 with no fee.
 */
export function fundShareBpsOf(entryFee: FloorEntryFee): number {
  const creator = creatorTermsOf(entryFee);
  return fundPercentOf(entryFee) * 100 + (creator === null ? 0 : creator.percent * creator.cut_percent);
}

/** A percent from basis points, with no trailing zeros (750 -> '7.5', 1520 -> '15.2', 1500 -> '15'). */
function percentWords(bps: number): string {
  return String(Number((bps / 100).toFixed(2)));
}

/**
 * Why an entry fee falls under the floor, as one plain sentence naming what it keeps and the fix (its fund_percent,
 * with or without a creator share); null when there is no fee, its amount_usd is 0, or it keeps FUND_FLOOR_PERCENT or
 * more of each fee (fundShareBpsOf).
 */
export function fundFloorIssue(entryFee: FloorEntryFee): string | null {
  if (entryFee === null || entryFee === undefined || entryFee.amount_usd === 0) return null;
  const bps = fundShareBpsOf(entryFee);
  if (bps >= FUND_FLOOR_PERCENT * 100) return null;
  return `an entry fee keeps at least ${FUND_FLOOR_PERCENT}% of each fee for ${FUND_NAME}, and this one keeps ${percentWords(bps)}%: set entry_fee.fund_percent to ${FUND_FLOOR_PERCENT} or more`;
}

/**
 * A fee of `feeCents` (a whole number of cents, 0 or more) split at `fundPercent` and, with one, `creator`'s share:
 * fund_cents is what reaches the fund's account (the fund or house share, plus make.fun's cut of the creator's share),
 * creator_cents what reaches the creator's account, creator_cut_cents make.fun's cut of the creator's share (inside
 * fund_cents), pot_cents the rest; every share rounded down to the cent, and pot_cents + fund_cents + creator_cents =
 * feeCents. Throws on a fee that is not whole cents, a percent out of range, or fundPercent + creator.percent above 100.
 */
export function entryFeeSplitCents(
  feeCents: number,
  fundPercent: number,
  creator: CreatorShareTerms | null = null,
): { pot_cents: number; fund_cents: number; creator_cents: number; creator_cut_cents: number } {
  if (!Number.isSafeInteger(feeCents) || feeCents < 0) throw new RangeError(`fee ${feeCents} is not a whole number of cents`);
  const { house, gross, cut } = splitOfCents(BigInt(feeCents), fundPercent, creator);
  return { pot_cents: feeCents - Number(house + gross), fund_cents: Number(house + cut), creator_cents: Number(gross - cut), creator_cut_cents: Number(cut) };
}

/**
 * A fee of `feeBaseUnits` (a token with `decimals` decimals) split at `fundPercent` and with `creator`, in whole cents
 * as entryFeeSplitCents splits it: fund what reaches the fund's account, creator what reaches the creator's,
 * creator_cut make.fun's cut of the creator's share (inside fund), pot the rest. Throws on decimals under 2 (or not an
 * integer), a negative fee, a fee that is not whole cents, a percent out of range, or fundPercent + creator.percent
 * above 100.
 */
export function entryFeeSplitBaseUnits(
  feeBaseUnits: bigint,
  fundPercent: number,
  decimals: number,
  creator: CreatorShareTerms | null = null,
): { pot: bigint; fund: bigint; creator: bigint; creator_cut: bigint } {
  if (!Number.isInteger(decimals) || decimals < 2) throw new RangeError(`decimals ${decimals}: a cent needs 2 or more`);
  if (feeBaseUnits < 0n) throw new RangeError(`fee ${feeBaseUnits} base units is negative`);
  const cent = 10n ** BigInt(decimals - 2);
  if (feeBaseUnits % cent !== 0n) throw new RangeError(`fee ${feeBaseUnits} base units is not whole cents at ${decimals} decimals`);
  const { house, gross, cut } = splitOfCents(feeBaseUnits / cent, fundPercent, creator);
  return { pot: feeBaseUnits - (house + gross) * cent, fund: (house + cut) * cent, creator: (gross - cut) * cent, creator_cut: cut * cent };
}

/** Where the fee goes, as one sentence: null at 0 (the whole fee joins the pot, as always). */
export function fundShareSentence(fundPercent: number): string | null {
  assertPercent(fundPercent);
  if (fundPercent === 0) return null;
  if (fundPercent === 100) return `The whole entry fee goes to ${FUND_NAME}, ${FUND_PURPOSE}; none of it joins this bounty's pot.`;
  return `${fundPercent}% of the entry fee goes to ${FUND_NAME}, ${FUND_PURPOSE}; the other ${100 - fundPercent}% joins this bounty's pot.`;
}

/** What a no-place refund returns, as one sentence: null at 0 (the whole fee is refunded). */
export function fundRefundSentence(fundPercent: number): string | null {
  assertPercent(fundPercent);
  if (fundPercent === 0) return null;
  if (fundPercent === 100) return 'None of it is refunded if nobody places.';
  return "The fund's share is never refunded: if nobody places, only the pot's share comes back.";
}

/** Where the creator's share goes in balance mode (CreatorShareTerms.to 'balance'): the sentence after creatorShareSentence's split. */
export const CREATOR_BALANCE_SENTENCE = "The creator's share is added to their make.fun balance, which they claim like other rewards.";

/**
 * Where a creator bounty's fee goes: one sentence with make.fun's house share (`housePercent`, the bundle's
 * fund_percent, when above 0), the creator's share, make.fun's cut of it (when any) and the pot's, then in balance mode
 * (`to` 'balance') CREATOR_BALANCE_SENTENCE. Wallet mode says the one sentence alone. With no house share it says what
 * it always said, so a bounty composed before the house share keeps its words (and its rules' hash).
 */
export function creatorShareSentence(c: CreatorShareTerms, housePercent = 0): string {
  assertPercent(housePercent, 'house percent');
  assertCreator(c, housePercent);
  const to = creatorPayoutOf(c) === 'balance' ? ` ${CREATOR_BALANCE_SENTENCE}` : '';
  const rest = 100 - housePercent - c.percent;
  const pot = rest === 0 ? "none of it joins this bounty's pot" : `the other ${rest}% joins this bounty's pot`;
  if (housePercent === 0) {
    const cut = c.cut_percent === 0 ? '' : `, less make.fun's ${c.cut_percent}% cut of that share, which goes to ${FUND_NAME}`;
    if (c.percent === 100) return `The whole entry fee goes to ${CREATOR_NAME}${cut}; none of it joins this bounty's pot.${to}`;
    return `${c.percent}% of the entry fee goes to ${CREATOR_NAME}${cut}; the other ${100 - c.percent}% joins this bounty's pot.${to}`;
  }
  const cut = c.cut_percent === 0 ? '' : `, less make.fun's ${c.cut_percent}% cut of that share, which goes to the fund too`;
  return `make.fun keeps ${housePercent}% of the entry fee for ${FUND_NAME}, and ${c.percent}% goes to ${CREATOR_NAME}${cut}; ${pot}.${to}`;
}

/**
 * What a no-place refund returns on a creator bounty, as one sentence: the creator's share (and make.fun's cut of it)
 * is never refunded, nor the house share (`housePercent`) beside it. When the shares take the whole fee nothing is.
 */
export function creatorRefundSentence(percent?: number, housePercent = 0): string {
  if (percent !== undefined && percent + housePercent === 100) return 'None of it is refunded if nobody places.';
  if (housePercent > 0) return "make.fun's and the creator's shares are never refunded: if nobody places, only the pot's share comes back.";
  return "The creator's share is never refunded: if nobody places, only the pot's share comes back.";
}

/** Dollars of whole cents: '$1.30'. */
const dollars = (cents: number): string => `$${(cents / 100).toFixed(2)}`;

/**
 * Who gets what of one fee of `feeCents`, in dollars (entryFeeSplitCents): what make.fun keeps (its house share
 * and its cut of the creator's share, each named when both are above 0), what the creator gets, and what joins the
 * pot. Null at a fee of 0, or when the whole fee joins the pot.
 */
export function feeSplitAmountsSentence(feeCents: number, fundPercent: number, creator: CreatorShareTerms | null = null): string | null {
  if (feeCents <= 0) return null;
  const split = entryFeeSplitCents(feeCents, fundPercent, creator);
  if (split.pot_cents === feeCents) return null;
  const house = split.fund_cents - split.creator_cut_cents;
  const parts: string[] = [];
  if (split.fund_cents > 0) {
    const of = house > 0 && split.creator_cut_cents > 0 ? ` (${dollars(house)} house share, ${dollars(split.creator_cut_cents)} cut of the creator's share)` : '';
    parts.push(`make.fun keeps ${dollars(split.fund_cents)}${of}`);
  }
  if (creator !== null) parts.push(`${CREATOR_NAME} gets ${dollars(split.creator_cents)}`);
  parts.push(`${dollars(split.pot_cents)} joins this bounty's pot`);
  const list = parts.length === 1 ? parts[0] : `${parts.slice(0, -1).join(', ')} and ${parts[parts.length - 1]}`;
  return `Of each ${dollars(feeCents)} fee, ${list}.`;
}

/** The creator's share beside a fee on a dock or a band ('40% to the creator'), as src/lib/bounty.ts fundShareTag says the fund's. */
export function creatorShareTag(percent: number): string {
  return `${percent}% to the creator`;
}

/**
 * The sentences for a fee's shares, whichever it has: with a creator share the creator's, the house share beside it
 * (creatorShareSentence, creatorRefundSentence, both at the fee's fund_percent), else the fund's (fundShareSentence,
 * fundRefundSentence); both null when the whole fee joins the pot (or no fee at all). Every new surface calls this one.
 */
export function feeShareSentences(entryFee: { fund_percent?: number; creator?: CreatorShareTerms } | null | undefined): { share: string | null; refund: string | null } {
  const creator = creatorTermsOf(entryFee);
  const fund = fundPercentOf(entryFee);
  if (creator !== null) return { share: creatorShareSentence(creator, fund), refund: creatorRefundSentence(creator.percent, fund) };
  return { share: fundShareSentence(fund), refund: fundRefundSentence(fund) };
}
