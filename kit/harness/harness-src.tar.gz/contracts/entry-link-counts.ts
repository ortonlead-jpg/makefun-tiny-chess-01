// The house's counts files: what the grader writes at a program/v1 entry link's `counts` path under /output
// (contracts/competition.ts ProgramEntryLink.counts, on a YouTube, an X, a TikTok or a make.fun link:
// COUNTS_ENTRY_LINK_PLATFORMS) after the entry's runs and before the scorer, so the scorer ranks the entry on counts the
// house read, never on a number the entry wrote. One JSON object, UTF-8, of at most ENTRY_LINK_COUNTS_MAX_BYTES, in one
// of four formats by the link's platform: a post's three told apart by `format` (parseEntryLinkCounts), a bounty's read
// alone (parseBountyCounts).
//
// A YouTube video's, EntryLinkCounts (ENTRY_LINK_COUNTS_FORMAT, makefun/video-counts/v1), of exactly these keys:
//
//   format    ENTRY_LINK_COUNTS_FORMAT, exactly
//   platform  'youtube'
//   video_id  the video's id, 11 of [A-Za-z0-9_-] (YOUTUBE_VIDEO_ID)
//   url       the video's address as the entry-link record holds it (https)
//   reading   'check', the reading taken when the entry was checked (a dev grade's), or 'deadline', the one taken at
//             the final phase's lock (a final grade's)
//   at        when that reading was taken (RFC 3339 with an offset)
//   video     'public', the video was read and public; 'gone', YouTube answered it absent or not public (the
//             entrant's), every count then null
//   views, likes, comments   each a whole count from 0, or null where YouTube showed none (hidden likes, comments off)
//
// An X post's, XPostCounts (POST_COUNTS_FORMAT, makefun/post-counts/v1), of exactly these keys:
//
//   format    POST_COUNTS_FORMAT, exactly
//   platform  'x'
//   post_id   the post's id, 1 to 20 decimal digits with no leading zero and below 2^64 (X_POST_ID, as
//             server/entry-link/x.ts reads a post's address)
//   url       the post's address as the entry-link record holds it (https)
//   reading   'check', the reading taken when the entry was checked (a dev grade's), or 'deadline', the one taken
//             after the final phase's lock by the house's deadline pass over the field (a final grade's)
//   at        when that reading was taken (RFC 3339 with an offset)
//   post      'public', the post was read; 'gone', X answered it deleted or not public (the entrant's), every count
//             then null
//   views, likes, replies, reposts, quotes   each a whole count from 0, or null where X showed none (a legacy post's
//             views)
//
// A TikTok video's, TiktokVideoCounts (TIKTOK_COUNTS_FORMAT, makefun/tiktok-counts/v1), of exactly these keys:
//
//   format    TIKTOK_COUNTS_FORMAT, exactly
//   platform  'tiktok'
//   video_id  the video's id, 1 to 20 decimal digits with no leading zero and below 2^64 (TIKTOK_VIDEO_ID, the id
//             in the video's address https://www.tiktok.com/@<handle>/video/<id>)
//   url       the video's address as the entry-link record holds it (https, at most 2,048 characters)
//   reading   'check', the reading taken when the entry was checked (a dev grade's), or 'deadline', the one taken
//             after the final phase's lock by the house's deadline pass over the field (a final grade's)
//   at        when that reading was taken (RFC 3339 with an offset)
//   video     'public', the video was read and public; 'gone', TikTok answered it deleted, not public, or not shown
//             to a visitor from the US (the entrant's), every count then null
//   views, likes, comments, shares, saves   each a whole count from 0 (TikTok's play, like, comment, share and save
//             counts), or null where none was shown
//
// makefun/video-counts/v1 and makefun/post-counts/v1 never change: gta6-clipper-01's and gta6-clipper-x-01's sealed
// scorers mirror them byte for byte. A scorer ranks a post's file on
// countsScoreOf: each count its bundle's `rank_by` names (ProgramEntryLink.rank_by; views alone where it names none)
// times its weight, a null count as 0, summed; a gone post scores 0.
//
// A make.fun bounty's, BountyCounts (BOUNTY_COUNTS_FORMAT, makefun/bounty-counts/v1), of exactly these keys:
//
//   format          BOUNTY_COUNTS_FORMAT, exactly
//   slug            the bounty's slug (primitives.ts Slug)
//   url             exactly https://make.fun/bounty/<slug>, the record's canonical address
//   reading         'check' (the intake reading, a dev grade's) or 'deadline' (the final lock's, capped at the
//                   contest's deadline: a final grade's)
//   read_at         when that reading was taken (RFC 3339 with an offset)
//   bounty          'live', the bounty was found approved and public; 'gone', it was not found, or is a draft,
//                   cancelled or internal (the entrant's), entrants and entry_fees_usd then null
//   entrants        the bounty's counted entrants up to the reading's cap, a whole count from 0, or null where gone
//   entry_fees_usd  the entry fees those entrants paid up to the cap, a USD decimal of whole cents (USD_DECIMAL), or
//                   null where gone
//   entry_fee_usd   the bounty's own entry fee, a USD decimal above 0.00
//
// 'gone' exactly when entrants and entry_fees_usd are both null. A bounty's file takes no `rank_by`: its bundle's
// scorer ranks it on its own rule.
//
// Pure: it imports nothing but zod and the primitives, so every reader may take it without the bundle contract. A
// bundle's scorer mirrors its format with its language's standard library alone (no import of this file).

import { z } from 'zod';
import { IsoDateTime, Slug } from './primitives.ts';

/** A video's counts file's format tag (EntryLinkCounts.format). */
export const ENTRY_LINK_COUNTS_FORMAT = 'makefun/video-counts/v1';

/** An X post's counts file's format tag (XPostCounts.format). */
export const POST_COUNTS_FORMAT = 'makefun/post-counts/v1';

/** A TikTok video's counts file's format tag (TiktokVideoCounts.format). */
export const TIKTOK_COUNTS_FORMAT = 'makefun/tiktok-counts/v1';

/** A bounty's counts file's format tag (BountyCounts.format). */
export const BOUNTY_COUNTS_FORMAT = 'makefun/bounty-counts/v1';

/** The most bytes a counts file holds, any format: 4 KiB, far past any one the grader writes (an address of at most 2,048 characters and five counts). */
export const ENTRY_LINK_COUNTS_MAX_BYTES = 4 * 1024;

/** A YouTube video's id: 11 letters, digits, underscores and hyphens. */
export const YOUTUBE_VIDEO_ID = /^[A-Za-z0-9_-]{11}$/;

/** An X post's id as server/entry-link/x.ts reads one: 1 to 20 decimal digits, no leading zero (XPostCounts also holds it below 2^64). */
export const X_POST_ID = /^[1-9][0-9]{0,19}$/;

/** A TikTok video's id as its address carries it: 1 to 20 decimal digits, no leading zero (TiktokVideoCounts also holds it below 2^64). */
export const TIKTOK_VIDEO_ID = /^[1-9][0-9]{0,19}$/;

/** Which reading a counts file carries (EntryLinkCounts.reading, BountyCounts.reading and the others'): the entry's check's (dev), or the final lock's (final). */
export const ENTRY_LINK_COUNTS_READINGS = ['check', 'deadline'] as const;
export type EntryLinkCountsReadingT = (typeof ENTRY_LINK_COUNTS_READINGS)[number];

/** What the platform answered of the video at that reading (EntryLinkCounts.video, YouTube's; TiktokVideoCounts.video, TikTok's). */
export const ENTRY_LINK_COUNTS_VIDEO = ['public', 'gone'] as const;
export type EntryLinkCountsVideoT = (typeof ENTRY_LINK_COUNTS_VIDEO)[number];

/** What the house found of the bounty at that reading (BountyCounts.bounty): approved and public, or gone. */
export const BOUNTY_COUNTS_BOUNTY = ['live', 'gone'] as const;
export type BountyCountsBountyT = (typeof BOUNTY_COUNTS_BOUNTY)[number];

/** A USD amount as a counts file writes it: whole dollars (no leading zero, at most 12 digits), a point and two cents digits. */
export const USD_DECIMAL = /^(0|[1-9][0-9]{0,11})\.[0-9]{2}$/;

/** What X answered of the post at that reading (XPostCounts.post). */
export const POST_COUNTS_POST = ['public', 'gone'] as const;
export type PostCountsPostT = (typeof POST_COUNTS_POST)[number];

/** One count: a whole number from 0, or null where the platform showed none. */
const Count = z.int().min(0).nullable();

/** A USD decimal string (USD_DECIMAL). */
const UsdDecimal = z.string().regex(USD_DECIMAL, 'a USD amount is written as dollars, a point and two cents digits, with no leading zero (such as "0.50" or "12.00")');

/** A video's counts, as the grader writes them for the scorer (the header). */
export const EntryLinkCounts = z
  .strictObject({
    format: z.literal(ENTRY_LINK_COUNTS_FORMAT),
    platform: z.literal('youtube'),
    video_id: z.string().regex(YOUTUBE_VIDEO_ID, "a YouTube video's id is 11 letters, digits, underscores and hyphens"),
    url: z
      .string()
      .max(2048)
      .regex(/^https:\/\/\S+$/, 'the video address is an https URL'),
    reading: z.enum(ENTRY_LINK_COUNTS_READINGS),
    at: IsoDateTime,
    video: z.enum(ENTRY_LINK_COUNTS_VIDEO),
    views: Count,
    likes: Count,
    comments: Count,
  })
  .refine((c) => c.video === 'public' || (c.views === null && c.likes === null && c.comments === null), {
    message: "a video read 'gone' carries no count: views, likes and comments are null",
    // Only on a file whose shape parsed.
    when: (payload) => payload.issues.length === 0,
  });
export type EntryLinkCountsT = z.infer<typeof EntryLinkCounts>;

/** A bounty's counts, as the grader writes them for the scorer (the header). */
export const BountyCounts = z
  .strictObject({
    format: z.literal(BOUNTY_COUNTS_FORMAT),
    slug: Slug,
    url: z.string().max(2048),
    reading: z.enum(ENTRY_LINK_COUNTS_READINGS),
    read_at: IsoDateTime,
    bounty: z.enum(BOUNTY_COUNTS_BOUNTY),
    entrants: Count,
    entry_fees_usd: UsdDecimal.nullable(),
    entry_fee_usd: UsdDecimal.refine((s) => /[1-9]/.test(s), { message: 'the entry fee is above 0.00', when: (payload) => payload.issues.length === 0 }),
  })
  .refine((c) => c.url === `https://make.fun/bounty/${c.slug}`, {
    path: ['url'],
    message: "the bounty's address is exactly https://make.fun/bounty/<slug>, of its own slug",
    // Only on a file whose shape parsed.
    when: (payload) => payload.issues.length === 0,
  })
  .refine((c) => (c.bounty === 'gone' ? c.entrants === null && c.entry_fees_usd === null : c.entrants !== null && c.entry_fees_usd !== null), {
    message: "a bounty is read 'gone' exactly when entrants and entry_fees_usd are both null: a live bounty carries both, a gone one neither",
    when: (payload) => payload.issues.length === 0,
  });
export type BountyCountsT = z.infer<typeof BountyCounts>;

/** An X post's counts, as the grader writes them for the scorer (the header). */
export const XPostCounts = z
  .strictObject({
    format: z.literal(POST_COUNTS_FORMAT),
    platform: z.literal('x'),
    post_id: z
      .string()
      .regex(X_POST_ID, "an X post's id is 1 to 20 decimal digits, no leading zero")
      .refine((id) => BigInt(id) < 2n ** 64n, {
        message: "an X post's id is below 2^64",
        // Only on an id of digits, which BigInt reads.
        when: (payload) => payload.issues.length === 0,
      }),
    url: z
      .string()
      .max(2048)
      .regex(/^https:\/\/\S+$/, 'the post address is an https URL'),
    reading: z.enum(ENTRY_LINK_COUNTS_READINGS),
    at: IsoDateTime,
    post: z.enum(POST_COUNTS_POST),
    views: Count,
    likes: Count,
    replies: Count,
    reposts: Count,
    quotes: Count,
  })
  .refine((c) => c.post === 'public' || (c.views === null && c.likes === null && c.replies === null && c.reposts === null && c.quotes === null), {
    message: "a post read 'gone' carries no count: views, likes, replies, reposts and quotes are null",
    // Only on a file whose shape parsed.
    when: (payload) => payload.issues.length === 0,
  });
export type XPostCountsT = z.infer<typeof XPostCounts>;

/** A TikTok video's counts, as the grader writes them for the scorer (the header). */
export const TiktokVideoCounts = z
  .strictObject({
    format: z.literal(TIKTOK_COUNTS_FORMAT),
    platform: z.literal('tiktok'),
    video_id: z
      .string()
      .regex(TIKTOK_VIDEO_ID, "a TikTok video's id is 1 to 20 decimal digits, no leading zero")
      .refine((id) => BigInt(id) < 2n ** 64n, {
        message: "a TikTok video's id is below 2^64",
        // Only on an id of digits, which BigInt reads.
        when: (payload) => payload.issues.length === 0,
      }),
    url: z
      .string()
      .max(2048)
      .regex(/^https:\/\/\S+$/, 'the video address is an https URL'),
    reading: z.enum(ENTRY_LINK_COUNTS_READINGS),
    at: IsoDateTime,
    video: z.enum(ENTRY_LINK_COUNTS_VIDEO),
    views: Count,
    likes: Count,
    comments: Count,
    shares: Count,
    saves: Count,
  })
  .refine((c) => c.video === 'public' || (c.views === null && c.likes === null && c.comments === null && c.shares === null && c.saves === null), {
    message: "a video read 'gone' carries no count: views, likes, comments, shares and saves are null",
    // Only on a file whose shape parsed.
    when: (payload) => payload.issues.length === 0,
  });
export type TiktokVideoCountsT = z.infer<typeof TiktokVideoCounts>;

/**
 * A counts file of any format (parseEntryLinkCounts), each typed with the others' own keys absent: a strict file never
 * holds them, so a reader may ask `counts.video_id`, `counts.post` or `counts.shares` of any and read undefined where
 * its format carries none.
 */
export type CountsFileT =
  | (EntryLinkCountsT & { post_id?: never; post?: never; replies?: never; reposts?: never; quotes?: never; shares?: never; saves?: never })
  | (XPostCountsT & { video_id?: never; video?: never; comments?: never; shares?: never; saves?: never })
  | (TiktokVideoCountsT & { post_id?: never; post?: never; replies?: never; reposts?: never; quotes?: never });

/**
 * The counts a platform's counts file carries, which a bundle's `rank_by` may weigh (contracts/competition.ts
 * ProgramEntryLink.rank_by): a YouTube video's views, likes and comments; an X post's views, likes, replies, reposts and
 * quotes; a TikTok video's views, likes, comments, shares and saves.
 */
export const COUNTS_RANK_KEYS = {
  youtube: ['views', 'likes', 'comments'],
  x: ['views', 'likes', 'replies', 'reposts', 'quotes'],
  tiktok: ['views', 'likes', 'comments', 'shares', 'saves'],
} as const;
export type CountsPlatformT = keyof typeof COUNTS_RANK_KEYS;

/** Every count any platform's file carries (COUNTS_RANK_KEYS, joined), in that order. */
export const COUNTS_RANK_KEYS_ALL = ['views', 'likes', 'comments', 'replies', 'reposts', 'quotes', 'shares', 'saves'] as const;
export type CountsRankKeyT = (typeof COUNTS_RANK_KEYS_ALL)[number];

/** A bundle's weights (ProgramEntryLink.rank_by): each count it names, to a whole weight. */
export type CountsRankByT = Readonly<Partial<Record<CountsRankKeyT, number>>>;

/** The weights a bundle naming no `rank_by` ranks on: views alone (gta6-clipper-01's score). */
export const COUNTS_RANK_BY_DEFAULT: CountsRankByT = Object.freeze({ views: 1 });

/** Whether a counts file reads its post gone (a YouTube or a TikTok video's `video`, an X post's `post`). */
export function countsGone(counts: CountsFileT): boolean {
  switch (counts.platform) {
    case 'youtube':
      return counts.video === 'gone';
    case 'x':
      return counts.post === 'gone';
    case 'tiktok':
      return counts.video === 'gone';
  }
}

/**
 * A counts file's score under `rankBy` (ProgramEntryLink.rank_by; absent, COUNTS_RANK_BY_DEFAULT, views alone): the sum
 * of each named count times its weight, a null count as 0; 0 for a post read gone. A key the file's platform does not
 * count reads 0 (the loader refuses such a rank_by: server/competitions/load.ts entryLinkIssues). Pure: it reads only
 * its arguments.
 */
export function countsScoreOf(counts: CountsFileT, rankBy: CountsRankByT | undefined): number {
  if (countsGone(counts)) return 0;
  const weights = rankBy ?? COUNTS_RANK_BY_DEFAULT;
  const read = counts as Readonly<Partial<Record<CountsRankKeyT, number | null>>>;
  let score = 0;
  for (const key of COUNTS_RANK_KEYS_ALL) {
    const weight = weights[key];
    if (weight === undefined) continue;
    score += weight * (read[key] ?? 0);
  }
  return score;
}

/**
 * A counts file's text, parsed by the schema `schemaOf` picks for its JSON, or the issues that refuse it: over
 * ENTRY_LINK_COUNTS_MAX_BYTES (refused before it is parsed), not JSON, or not that schema. Pure: it reads only its
 * arguments.
 */
function parseCounts(text: string, schemaOf: (raw: unknown) => z.ZodType): { ok: true; counts: unknown } | { ok: false; issues: string[] } {
  const bytes = new TextEncoder().encode(text).byteLength;
  if (bytes > ENTRY_LINK_COUNTS_MAX_BYTES) return { ok: false, issues: [`${bytes} bytes, over the ${ENTRY_LINK_COUNTS_MAX_BYTES} a counts file holds`] };
  let raw: unknown;
  try {
    raw = JSON.parse(text);
  } catch {
    return { ok: false, issues: ['not JSON'] };
  }
  const r = schemaOf(raw).safeParse(raw);
  if (r.success) return { ok: true, counts: r.data };
  return { ok: false, issues: r.error.issues.map((i) => `${i.path.length > 0 ? `${i.path.join('.')}: ` : ''}${i.message}`) };
}

/**
 * A post's counts file's text, parsed, or the issues that refuse it (parseCounts): a file whose `format` is
 * POST_COUNTS_FORMAT is read as XPostCounts, one whose `format` is TIKTOK_COUNTS_FORMAT as TiktokVideoCounts, any other
 * as EntryLinkCounts (so a file of no format is refused as a YouTube video's, in the words it was before the other
 * formats existed). A bounty's file is parseBountyCounts'. Pure: it reads only `text`.
 */
export function parseEntryLinkCounts(text: string): { ok: true; counts: CountsFileT } | { ok: false; issues: string[] } {
  const r = parseCounts(text, (raw) => {
    const format = typeof raw === 'object' && raw !== null && !Array.isArray(raw) ? (raw as { format?: unknown }).format : undefined;
    return format === POST_COUNTS_FORMAT ? XPostCounts : format === TIKTOK_COUNTS_FORMAT ? TiktokVideoCounts : EntryLinkCounts;
  });
  return r.ok ? { ok: true, counts: r.counts as CountsFileT } : r;
}

/** A bounty's counts file's text, parsed, or the issues that refuse it (parseCounts). Pure: it reads only `text`. */
export function parseBountyCounts(text: string): { ok: true; counts: BountyCountsT } | { ok: false; issues: string[] } {
  const r = parseCounts(text, () => BountyCounts);
  return r.ok ? { ok: true, counts: r.counts as BountyCountsT } : r;
}
